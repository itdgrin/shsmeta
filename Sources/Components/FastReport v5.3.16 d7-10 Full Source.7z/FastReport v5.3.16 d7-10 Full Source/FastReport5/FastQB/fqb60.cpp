
#include <basepch.h>
#pragma hdrstop
USEFORMNS("fqbSynmemo.pas", Fqbsynmemo, fqbSynmemo); 
USEFORMNS("fqbLinkForm.pas", Fqblinkform, fqbLinkForm); 
USEFORMNS("fqbDesign.pas", Fqbdesign, fqbDesign); 
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------

